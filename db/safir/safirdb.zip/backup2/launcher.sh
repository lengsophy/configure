mongoimport --db meteor --collection answerquizz --drop --file answerquizz.json --jsonArray
wait
mongoimport --db meteor --collection attribute --drop --file attribute.json --jsonArray
wait
mongoimport --db meteor --collection attribute_value --drop --file attribute_value.json --jsonArray
wait
mongoimport --db meteor --collection banner --drop --file banner.json --jsonArray
wait
mongoimport --db meteor --collection card --drop --file card.json --jsonArray
wait
mongoimport --db meteor --collection cart --drop --file cart.json --jsonArray
wait
mongoimport --db meteor --collection categories --drop --file categories.json --jsonArray
wait
mongoimport --db meteor --collection cfs.images.filerecord --drop --file cfs.images.filerecord.json --jsonArray
wait
mongoimport --db meteor --collection cfs._tempstore --drop --file cfs._tempstore.json --jsonArray
wait
mongoimport --db meteor --collection contents --drop --file contents.json --jsonArray
wait
mongoimport --db meteor --collection contents_type --drop --file contents_type.json --jsonArray
wait
mongoimport --db meteor --collection daily --drop --file daily.json --jsonArray
wait
mongoimport --db meteor --collection discount --drop --file discount.json --jsonArray
wait
mongoimport --db meteor --collection favorite --drop --file favorite.json --jsonArray
wait
mongoimport --db meteor --collection journey --drop --file journey.json --jsonArray
wait
mongoimport --db meteor --collection linkselling --drop --file linkselling.json --jsonArray
wait
mongoimport --db meteor --collection list_product --drop --file list_product.json --jsonArray
wait
mongoimport --db meteor --collection meteor_accounts_loginServiceConfiguration --drop --file meteor_accounts_loginServiceConfiguration.json --jsonArray
wait
mongoimport --db meteor --collection meteor_oauth_pendingCredentials --drop --file meteor_oauth_pendingCredentials.json --jsonArray
wait
mongoimport --db meteor --collection meteor_oauth_pendingRequestTokens --drop --file meteor_oauth_pendingRequestTokens.json --jsonArray
wait
mongoimport --db meteor --collection mouse --drop --file mouse.json --jsonArray
wait
mongoimport --db meteor --collection order --drop --file order.json --jsonArray
wait
mongoimport --db meteor --collection p2 --drop --file p2.json --jsonArray
wait
mongoimport --db meteor --collection parent_tags --drop --file parent_tags.json --jsonArray
wait
mongoimport --db meteor --collection parentattr --drop --file parentattr.json --jsonArray
wait
mongoimport --db meteor --collection payment --drop --file payment.json --jsonArray
wait
mongoimport --db meteor --collection posts --drop --file posts.json --jsonArray
wait
mongoimport --db meteor --collection products --drop --file products.json --jsonArray
wait
mongoimport --db meteor --collection question --drop --file question.json --jsonArray
wait
mongoimport --db meteor --collection quizz --drop --file quizz.json --jsonArray
wait
mongoimport --db meteor --collection shops --drop --file shops.json --jsonArray
wait
mongoimport --db meteor --collection stock --drop --file stock.json --jsonArray
wait
mongoimport --db meteor --collection roles --drop --file roles.json --jsonArray
wait
mongoimport --db meteor --collection tags --drop --file tags.json --jsonArray
wait
mongoimport --db meteor --collection tracking --drop --file tracking.json --jsonArray
wait
mongoimport --db meteor --collection translation --drop --file translation.json --jsonArray
wait
mongoimport --db meteor --collection users --drop --file users.json --jsonArray
wait
mongoimport --db meteor --collection userTracking --drop --file userTracking.json --jsonArray