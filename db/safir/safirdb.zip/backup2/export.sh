mongoexport --db meteor --collection answerquizz --out answerquizz.json
wait
mongoexport --db meteor --collection attribute --out attribute.json
wait
mongoexport --db meteor --collection attribute_value --out attribute_value.json
wait
mongoexport --db meteor --collection banner --out banner.json
wait
mongoexport --db meteor --collection card --out card.json
wait
mongoexport --db meteor --collection cart --out cart.json
wait
mongoexport --db meteor --collection categories --out categories.json
wait
mongoexport --db meteor --collection cfs.images.filerecord --out cfs.images.filerecord.json
wait
mongoexport --db meteor --collection cfs._tempstore --out cfs._tempstore.json
wait
mongoexport --db meteor --collection contents --out contents.json
wait
mongoexport --db meteor --collection contents_type --out contents_type.json
wait
mongoexport --db meteor --collection daily --out daily.json
wait
mongoexport --db meteor --collection discount --out discount.json
wait
mongoexport --db meteor --collection favorite --out favorite.json
wait
mongoexport --db meteor --collection journey --out journey.json
wait
mongoexport --db meteor --collection linkselling --out linkselling.json
wait
mongoexport --db meteor --collection list_product --out list_product.json
wait
mongoexport --db meteor --collection meteor_accounts_loginServiceConfiguration --out meteor_accounts_loginServiceConfiguration.json
wait
mongoexport --db meteor --collection meteor_oauth_pendingCredentials --out meteor_oauth_pendingCredentials.json
wait
mongoexport --db meteor --collection meteor_oauth_pendingRequestTokens --out meteor_oauth_pendingRequestTokens.json
wait
mongoexport --db meteor --collection mouse --out mouse.json
wait
mongoexport --db meteor --collection order --out order.json
wait
mongoexport --db meteor --collection p2 --out p2.json
wait
mongoexport --db meteor --collection parentattr --out parentattr.json
wait
mongoexport --db meteor --collection parent_tags --out parent_tags.json
wait
mongoexport --db meteor --collection payment --out payment.json
wait
mongoexport --db meteor --collection posts --out posts.json
wait
mongoexport --db meteor --collection products --out products.json
wait
mongoexport --db meteor --collection question --out question.json
wait
mongoexport --db meteor --collection quizz --out quizz.json
wait
mongoexport --db meteor --collection roles --out roles.json
wait
mongoexport --db meteor --collection shops --out shops.json
wait
mongoexport --db meteor --collection stock --out stock.json
wait
mongoexport --db meteor --collection tags --out tags.json
wait
mongoexport --db meteor --collection tracking --out tracking.json
wait
mongoexport --db meteor --collection translation --out translation.json
wait
mongoexport --db meteor --collection users --out users.json
wait
mongoexport --db meteor --collection userTracking --out userTracking.json
